from libfinal import iot_notification_system  # Replace with your actual library and module names

# Example usage of your library
iot_notification_system.some_function()

from libfinal.iot_notification_system import some_function, another_function  # Replace with your library's actual functions

# Test your library's functions
print("Testing some_function:")
some_function()

print("Testing another_function:")
another_function("Test input")  # Adjust this as needed

