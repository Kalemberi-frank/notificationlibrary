def some_function():
    print('IoT Notification System: Function executed successfully!')
